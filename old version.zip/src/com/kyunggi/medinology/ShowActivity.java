package com.kyunggi.medinology;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.tts.*;
import android.widget.*;
import java.util.*;


public class ShowActivity extends Activity implements TextToSpeech.OnInitListener
{
	private TextToSpeech myTTS;
	String disease1;
	String disease2;
	String disease3;
	@Override
	public void onInit(int p1)
	{
        Locale enUs = new Locale("korea");  //Locale("en_US");
        if (myTTS.isLanguageAvailable(enUs) == TextToSpeech.LANG_AVAILABLE)
        {
			myTTS.setLanguage(enUs);
		}
        else
		{
            myTTS.setLanguage(Locale.KOREA);
        }
        //myTTS.setLanguage(Locale.US);   // 언어 설정 , 단말기에 언어 없는 버전에선 안되는듯
        myTTS.setPitch((float) 0.1);  // 높낮이 설정 1이 보통, 6.0미만 버전에선 높낮이도 설정이 안됨
        myTTS.setSpeechRate(1); // 빠르기 설정 1이 보통
        //myTTS.setVoice(); 
		myTTS.speak("결 과.  이용자님의 진단 질병과 해당 약은 다음과 같습니다.", TextToSpeech.QUEUE_FLUSH, null);  // tts 변환되어 나오는 음성
		myTTS.speak(disease1, TextToSpeech.QUEUE_ADD, null);    //QUEUE_FLUSH 다음에 나오는 QUEUE_ADD
        myTTS.speak(disease2, TextToSpeech.QUEUE_ADD, null);    //QUEUE_FLUSH 다음에 나오는 QUEUE_ADD
		myTTS.speak(disease3, TextToSpeech.QUEUE_ADD, null);    //QUEUE_FLUSH 다음에 나오는 QUEUE_ADD
		myTTS.speak("쾌유를 빕니다", TextToSpeech.QUEUE_ADD, null);
		myTTS.speak("면책 : 이 결과를 맹신하는 것은 위험할 수 있으므로 반드시 병원에서 의사와 상담하시기 바랍니다.", TextToSpeech.QUEUE_ADD, null);
	}

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
		setContentView(R.layout.showresult);
		// Get the message from the intent
        Intent intent = getIntent();
        disease1 = intent.getStringExtra("com.kyunggi.medinology.diseaseone.MESSAGE");
		disease2 =  intent.getStringExtra("com.kyunggi.medinology.diseasetwo.MESSAGE");
		disease3 = intent.getStringExtra("com.kyunggi.medinology.diseasethree.MESSAGE");
        TextView disOneTextView = (TextView)findViewById(R.id.diseaseoneTextView);
        disOneTextView.setText(disease1);
		TextView disTwoTextView = (TextView)findViewById(R.id.diseasetwoTextView);
        disTwoTextView.setText(disease2);
		TextView disThreeTextView=(TextView)findViewById(R.id.diseasethreeTextView);
		disThreeTextView.setText(disease3);
		myTTS = new TextToSpeech(this, this);

	}
	@Override
    protected void onDestroy()
	{
        super.onDestroy();
        myTTS.shutdown();  //speech 리소스 해제
    }
}
